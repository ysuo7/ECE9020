import javax.swing.*;
import java.awt.*;

public class Panel extends JPanel {
    public Panel(){
        this.setBackground(Color.DARK_GRAY);
        this.setSize(new Dimension(150, 600));
    }
}
