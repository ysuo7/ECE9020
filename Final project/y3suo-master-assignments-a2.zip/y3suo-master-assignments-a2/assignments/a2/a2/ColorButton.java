import javax.swing.*;
import java.awt.*;

public class ColorButton extends JButton {
    public ColorButton(Color c){
        this.setPreferredSize(new Dimension(50,30));
    }
}
