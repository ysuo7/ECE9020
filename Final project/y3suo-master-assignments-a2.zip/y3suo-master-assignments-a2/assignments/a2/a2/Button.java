import javax.swing.*;
import java.lang.String;

public class Button extends JButton {
    public Button(ImageIcon name){
        this.setIcon(name);
    }
}
